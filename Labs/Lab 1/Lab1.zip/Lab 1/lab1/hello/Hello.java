/**
   Hello, World program in a Java application

   Jim Teresco
   The College of Saint Rose
   Software Engineering, CSC 507, Spring 2015

   $Id: Hello.java 2510 2015-01-01 20:14:48Z terescoj $
*/

public class Hello {

    public static void main(String args[]) {

        System.out.println("Hello, Java application world!");
	System.out.println("Hello from Ikhlas & Dev!");
	System.out.println("Thanks for running, " + args[0] + "!");
    }

}