/*
  Hello, world example in C

  Jim Teresco
  The College of Saint Rose
  Programming Unix in C, Fall 2013
  Software Engineering, Spring 2014

  $Id: hello.c 2300 2014-01-13 02:22:33Z terescoj $
*/

#include <stdio.h>

int main() {

  printf("Hello, C World!\n");
  return 0;
} 
